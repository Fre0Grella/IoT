#ifndef RESTORELIGHTS_SLEEP_H
#define RESTORELIGHTS_SLEEP_H

void goSleep();

#endif