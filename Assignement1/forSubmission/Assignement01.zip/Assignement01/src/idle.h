#ifndef RESTORELIGHTS_IDLE_H
#define RESTORELIGHTS_IDLE_H

void pulse();

#endif