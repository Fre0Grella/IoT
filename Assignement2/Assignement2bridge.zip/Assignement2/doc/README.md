# link per il diagramma degli stati

https://lucid.app/lucidchart/6d24ce47-a0b3-455f-98e1-c2ebd56b11ad/edit?viewport_loc=27%2C76%2C2678%2C1352%2C0_0&invitationId=inv_b27fa435-f064-43f5-b57b-7d46e2acdaf8

# link per schema Tinkercad

https://www.tinkercad.com/things/1udeQZqiijc-assignement2-smartwash/editel

# Description of the solution of the project

## Initial Approach

Initially, we implemented a solution where all the components had his own task which could have been active or not.

## Actual Solution

After having some dependencies problems by using the first method we decided to totally change approach and created only few tasks grouping all the others and dividing them by states. The first of the two main tasks is implementing the sleep of the Arduino and the whole part about the check in out Area, on the second task there's the part about the washing area where there's even the maintanance control using the temperature sensor.