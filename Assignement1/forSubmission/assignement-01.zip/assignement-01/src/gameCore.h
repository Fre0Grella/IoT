#ifndef RESTORELIGHTS_CORE_H
#define RESTORELIGHTS_CORE_H

void gameState();

#endif